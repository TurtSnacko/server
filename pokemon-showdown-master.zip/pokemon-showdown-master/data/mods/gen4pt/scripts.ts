export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen4',
};
