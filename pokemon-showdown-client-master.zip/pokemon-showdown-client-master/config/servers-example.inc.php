<?php

$PokemonServers = array (
  'showdown' => 
  array (
    'name' => 'Smogon University',
    'id' => 'showdown',
    'server' => 'sim.psim.us',
    'port' => 8000,
  ),
);
