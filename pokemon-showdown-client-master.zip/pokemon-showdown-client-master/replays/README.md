PS replays database
===================

This is the code powering https://replay.pokemonshowdown.com/


JSON API
--------

The replays database has a JSON API, documented at:

https://github.com/smogon/pokemon-showdown-client/blob/master/WEB-API.md
