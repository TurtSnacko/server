export const FormatsData: {[k: string]: ModdedSpeciesFormatsData} = {
	pichuspikyeared: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
};
